#include <msp430g2553.h>

#define SWDELAY 0x0003		//delay time

void SWtimer(int);

int main(void)
{
	volatile int meas_basehigh, meas_baselow;
	volatile int released = 0x0001;

    WDTCTL = WDTPW | WDTHOLD;	// Stop watchdog timer
	
    P1DIR |= 0xff;			//set PIN6 to out
    P1OUT &= 0x00;			//P1 outputs 0

    P2DIR &= ~BIT5;			//P2.5 input
	P2SEL &= ~BIT5;
	P2SEL2 |= BIT5;

	TA0CTL = TASSEL_3;
	TA0CCTL1 = CM_3 + CCIS_2 + CAP;
	TA0CTL |= MC_2 + TACLR;
	SWtimer(SWDELAY);
	TA0CCTL1 ^= CCIS0;

	meas_basehigh = TA0CCR1;
	TA0CTL &= (MC1 + MC0);
	meas_basehigh--;
	meas_baselow = meas_basehigh - 0x0005;

    while(1)
    {
		volatile int current;

		TA0CTL = TASSEL_3;
		TA0CCTL1 = CM_3 + CCIS_2 + CAP;
		TA0CTL |= MC_2 + TACLR;
		SWtimer(SWDELAY);
		TA0CCTL1 ^= CCIS0;
		current = TA0CCR1;
		TA0CTL &= ~(MC1 + MC0);

		if (current >= meas_basehigh)
		{
			released = 0x0001;
		}

		else if (current <= meas_baselow)
		{
			P1OUT ^= released;
			released = 0x0000;
		}
    }

	return 0;
}

void SWtimer(int delay)				//waits for delay*delay decrements
{
	volatile unsigned int wait = delay;
	volatile unsigned int count1 = wait;
	volatile unsigned int count2 = wait;

	while(count1 > 0)
	{
		while(count2 > 0)
		{
			count2--;
		}
		count1--;
		count2 = wait;
	}
	return;
}
