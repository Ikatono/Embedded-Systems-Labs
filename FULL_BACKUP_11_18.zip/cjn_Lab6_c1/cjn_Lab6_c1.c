#include <msp430g2553.h>

#define PWMPeriod 250	//period of each blink
#define PWMDC1 200		//80%
#define PWMDC2 50		//20%
#define SWdelay 250	//delay time

void SWtimer(int);

int main(void)
{
    WDTCTL = WDTPW | WDTHOLD;	// Stop watchdog timer
	
    P1DIR |= BIT6;			//set PIN6 to out
    P1SEL |= BIT6;			//set PIN6 to peripheral

    TACTL = TASSEL1 + ID1 + ID0 + TACLR;	//SMCLK, Clear TA
    TACCTL1 = OUTMOD1;		//output mode 1
    TACCR0 = PWMPeriod;		//set timer period

    while(1)
    {
    	TACTL &= ~(MC1 + MC0);		//set timer for PWMDC1
    	TACCR1 = PWMDC1;
    	TACTL |= MC1 + MC0;

    	SWtimer(SWdelay);			//wait a bit

    	TACTL &= ~(MC1 + MC0);		//set timer for PWMDC2
    	TACCR1 = PWMDC2;
    	TACTL |= MC1 + MC0;

    	SWtimer(SWdelay);			//wait a bit
    }

	return 0;
}

void SWtimer(int delay)				//waits for delay*delay decrements
{
	volatile unsigned int wait = delay;
	volatile unsigned int count1 = wait;
	volatile unsigned int count2 = wait;

	while(count1 > 0)
	{
		while(count2 > 0)
		{
			count2--;
		}
		count1--;
		count2 = wait;
	}
	return;
}
