#include <msp430g2553.h>
//#include <intrinsics.h>



/*
 * main.c
 */
int gotConversion = 0;
volatile unsigned int data[32];
volatile int count = -1;
int done = 0;					//exists solely for debug purposes

int main(void) {


	WDTCTL = WDTPW + WDTHOLD;	// Stop watchdog timer

    ADC10AE0 = 1;				//set P1.0
    TACCR0 = 9999;				//set period of 10 ms (assuming 1MHz)

    __enable_interrupt();
    _BIS_SR(GIE);			//enable general interrupts

    TACTL = TASSEL0 + ID0 + MC1 + TACLR + TAIE;		//start timerA



    while(count < 31){};

    __disable_interrupt();
    TACTL &= ~(MC0 + TACLR);
    done = 1;

}


/*
#pragma vector = TIMER0_A0_VECTOR
__interrupt void TA_FFF2_ISR(void) {
	// Timer FFF2 ISR CODE HERE
	// Only CCIE on CCR0 block generates an interrupt at this vector
	return;
}
*/

#pragma vector = TIMER0_A1_VECTOR
__interrupt void TA_FFF0_ISR(void) {
	// Timer FFF0 ISR CODE HERE
	// Three sources (TAIE, CCIE on CCR1 and CCIE on CCR2) all generate interrupts at this vector



	count += 1;

	ADC10CTL0 = 0;		//Clear configuration registers just in case
	ADC10CTL1 = 0;		//some values were left on by a prior routine

	//ADC10CTL0 configuration based on the CLR instruction above and the one below:
	//SREF=001, ADC10SHT=64*ADC10CLKs, ADC10SR=0, REFOUT=0, REFBURST=0, MSC=0,
	//REF2_5=0, REFON=1, ADC10ON=1, ADC10IE=1, ADC10IFG=0, ENC=0, ADC10SC=0
	ADC10CTL0 |= SREF_1 + ADC10SHT_3 + REFON + ADC10ON + ADC10IE;

	//ADC10CTL1 configuration based on the CLR instruction above and the ones below:
	//INCH=1010, SHS=00, ADC10DF=0, ISSH=0, ADC10DIV=/8, ADC10SSEL=00,
	//CONSEQ=00, ADC10BUSY=0
	ADC10CTL1 = INCH_0 + ADC10DIV_7;

	//__enable_interrupt();

	ADC10CTL0 |= ENC + ADC10SC;

	while(gotConversion == 0)
	{

	}


	gotConversion = 0;
	return;
}

#pragma vector=ADC10_VECTOR
__interrupt void ADC10_ISR(void) {
	// ADC10 ISR CODE HERE

	data[count] = ADC10MEM;
	gotConversion = 1;

	return;
}
