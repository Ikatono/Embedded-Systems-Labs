#include <msp430g2553.h>

//MAKE SURE TO CHANGE WHICH IS THE INPUT PIN!

#define LEFT 0x10
#define DOWN 0x80
#define RIGHT 0x78
#define UP 0xE8
#define CENTER 1
#define SWDELAY 3

void SWtimer (int);

volatile unsigned int meas_base[5];
volatile unsigned char meas_crt[5];
volatile unsigned int i;

int main(void)
{
    WDTCTL = WDTPW | WDTHOLD;	// Stop watchdog timer
	


	P1DIR |= 0xff;			//set PIN6 to out
    P1OUT &= 0x00;			//P1 outputs 0

    P2DIR = 0;			//P2.5 input
	P2SEL = 0;
	P2SEL2 = 0xff;

	for (i = 0; i <= 4; i++)
	{
		TA0CTL = TASSEL_3;
		TA0CCTL1 = CM_3 + CCIS_2 + CAP;
		TA0CTL |= MC_2 + TACLR;
		SWtimer(SWDELAY);
		TA0CCTL1 ^= CCIS0;

		meas_base[i] = TA0CCR1 - 5;

		TA0CTL &= ~(MC1 + MC0);
	}

	while (1)
	{
		meas_crt[0] = 0;
		meas_crt[1] = 0;
		meas_crt[2] = 0;
		meas_crt[3] = 0;
		meas_crt[4] = 0;

		for (i = 0; i <= 4; i++)
		{
			TA0CTL = TASSEL_3;
			TA0CCTL1 = CM_3 + CCIS_2 + CAP;
			TA0CTL |= MC_2 + TACLR;
			SWtimer(SWDELAY);
			TA0CCTL1 ^= CCIS0;

			meas_crt[i] = TA0CCR1 <= meas_base[i];

			TA0CTL &= ~(MC1 + MC0);
		}

		/* causes error if and meas_cry is greater than 1
		for (i = 0; i <= 4; i++)
		{
			if (meas_crt[i] > 1)
			{
				while(1)
				{
					P1OUT = 1;
					SWtimer(SWDELAY*3);
					P1OUT = 0;
					SWtimer(SWDELAY*3);
				}
			}
		}
		*/

		if(meas_crt[0]) P1OUT = LEFT;
		else if(meas_crt[1]) P1OUT = DOWN;
		else if(meas_crt[2]) P1OUT = RIGHT;
		else if(meas_crt[3]) P1OUT = UP;
		else if(meas_crt[4]) P1OUT = CENTER;
		else P1OUT = 0;


	}

	return 0;
}

void SWtimer(int delay)				//waits for delay*delay decrements
{
	volatile unsigned int wait = delay;
	volatile unsigned int count1 = wait;
	volatile unsigned int count2 = wait;

	while(count1 > 0)
	{
		while(count2 > 0)
		{
			count2--;
		}
		count1--;
		count2 = wait;
	}
	return;
}

