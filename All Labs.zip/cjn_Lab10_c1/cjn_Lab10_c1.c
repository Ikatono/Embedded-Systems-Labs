#include <msp430g2553.h>

#define LEFTPIN 2
#define RIGHTPIN 8
#define UPPIN 16
#define DOWNPIN 4
#define CENTERPIN 32
#define LEFT 0
#define RIGHT 1
#define UP 2
#define DOWN 3
#define CENTER 4
#define OFFSET 9
#define SWDELAY 3
#define UPPRESSED 0
#define DOWNPRESSED 1
#define LEFTPRESSED 0
#define RIGHTPRESSED 2

char CheckCenter();
void SetBaselines();
unsigned int MeasureSensor(char);
void PrepPins();
char WaitForUpDown();
char WaitForLeftRight(char);
void SWtimer(unsigned int);
void Capture(char);
char Display(char);
void Blink(char,char);

volatile unsigned int baseline[5];
volatile unsigned int current[5];
volatile char upDown;
volatile char udlr;
volatile char SWFlag;
volatile unsigned int digital[20];
volatile char nextCapture;

int main(void)
{
    WDTCTL = WDTPW | WDTHOLD;	// Stop watchdog timer
	
    nextCapture = 0;

    PrepPins();
    SetBaselines();
    while(!CheckCenter());
    while(1)
    {
    	upDown = WaitForUpDown();
    	udlr = WaitForLeftRight(upDown);
    	Capture(udlr);
    	while(!nextCapture)
    	{
    		nextCapture = Display(udlr);
    	}
    	nextCapture = 0;
    	P1OUT = 0;
    }
	return 0;
}

void PrepPins()
{
	P1DIR |= 0xff;			//set PIN6 to out
	P1OUT &= 0x00;			//P1 outputs 0

	P2DIR = 0;
	P2SEL = 0;
	P2SEL2 = 0;
}

void SetBaselines()
{
	baseline[LEFT] = MeasureSensor(LEFTPIN) - OFFSET;
	baseline[RIGHT] = MeasureSensor(RIGHTPIN) - OFFSET;
	baseline[UP] = MeasureSensor(UPPIN) - OFFSET;
	baseline[DOWN] = MeasureSensor(DOWNPIN) - OFFSET;
	baseline[CENTER] = MeasureSensor(CENTERPIN) - OFFSET;
}

char CheckCenter()
{
	current[CENTER] = MeasureSensor(CENTERPIN);
	if(current[CENTER] <= baseline[4]) return 1;
	return 0;
}

char WaitForUpDown()
{
	while(1)
	{
		current[UP] = MeasureSensor(UPPIN);
		current[DOWN] = MeasureSensor(DOWNPIN);
		if(current[UP] <= baseline[UP]) return UPPRESSED;
		if(current[DOWN] <= baseline[DOWN]) return DOWNPRESSED;
	}
}

char WaitForLeftRight(char upOrDown)
{
	volatile char ud = upOrDown;

	while(1)
	{
		current[LEFT] = MeasureSensor(LEFTPIN);
		current[RIGHT] = MeasureSensor(RIGHTPIN);
		if(current[LEFT] <= baseline[LEFT]) return LEFTPRESSED + ud;
		if(current[RIGHT] <= baseline[RIGHT]) return RIGHTPRESSED + ud;
	}
}

unsigned int MeasureSensor(char sensor)
{
	volatile unsigned int data;

	P2SEL2 = sensor;

	TA0CTL = TASSEL_3;
	TA0CCTL1 = CM_3 + CCIS_2 + CAP;
	TA0CTL |= MC_2 + TACLR;
	SWtimer(SWDELAY);
	TA0CCTL1 ^= CCIS0;

	data = TA0CCR1;

	TA0CTL &= ~(MC1 + MC0);

	P2SEL2 = 0;

	return data;
}

void SWtimer(unsigned int delayTime)
{
	volatile unsigned int wait = delayTime;
	volatile unsigned int count1 = wait;
	volatile unsigned int count2 = wait;

	while(count1 > 0)
	{
		while(count2 > 0)
		{
			count2--;
		}
		count1--;
		count2 = wait;
	}
	return;
}

void Capture(char settings)
{
	volatile char vert = (settings & DOWNPRESSED > 0);
	//volatile char hor = (settings & RIGHTPRESSED > 0);
	volatile char captures = 0;

	SWFlag = 0;
	__enable_interrupt();
	TACCR0 = 5000;
	//sets CLK divider of 2 if up was pressed
	TACTL = TASSEL_2 + ID_1 - (ID_1 * vert) + MC_1 + TACLR + TAIE;

	while(captures < 20)
	{
		while(!SWFlag);
		ADC10CTL0 = 0;		//Clear configuration registers just in case
		ADC10CTL1 = 0;		//some values were left on by a prior routine

	 	//ADC10CTL0 configuration based on the CLR instruction above and the one below:
	   	//SREF=001, ADC10SHT=64*ADC10CLKs, ADC10SR=0, REFOUT=0, REFBURST=0, MSC=0,
	   	//REF2_5=0, REFON=1, ADC10ON=1, ADC10IE=1, ADC10IFG=0, ENC=0, ADC10SC=0
	   	ADC10CTL0 |= SREF_1 + ADC10SHT_3 + REFON + ADC10ON + ADC10IE;

	   	//ADC10CTL1 configuration based on the CLR instruction above and the ones below:
	   	//INCH=1010, SHS=00, ADC10DF=0, ISSH=0, ADC10DIV=/8, ADC10SSEL=00,
	   	//CONSEQ=00, ADC10BUSY=0
	   	ADC10CTL1 = INCH_0;// + ADC10DIV_7;

    	ADC10CTL0 |= ENC + ADC10SC;

    	while(SWFlag);
    	digital[captures] = ADC10MEM;
    	captures++;
	}

	__disable_interrupt();
}

//outputs all twenty samples
//if center is pressed between displays the loop will break
char Display(char settings)
{
	//volatile char vert = (settings & DOWNPRESSED > 0);
	volatile char hor = (settings & RIGHTPRESSED > 0);
	volatile char val;
	volatile char count;
	volatile unsigned int temp;

	for(count = 0; count < 20; count++)
	{
		val = 0;
		temp = digital[count];
		while (temp > 0)
		{
			temp >>= 1;
			val++;
		}
		if(val > 0) val--;
		if(val > 0) val--;
		Blink(val, hor);
		if(CheckCenter()) return 1;
	}
	return 0;
}

void Blink(char val, char setting)
{
	volatile char leds = val;
	volatile char divider = setting + 1;
	volatile char pos;
	volatile char neg;
	volatile unsigned int count = 0;

	pos = (128 * (leds >= 1)) + (64 * (leds >= 2)) + (32 * (leds >= 3)) + (16 * (leds >= 4));
	neg = 8 + (16 * (leds < 5)) + (32 * (leds < 6)) + (64 * (leds < 7)) + (128 * (leds < 8));

	SWFlag = 0;
	__enable_interrupt();
	TACCR0 = 1000;
	TACTL = TASSEL_2 + ID1 + MC_1 + TACLR + TAIE;

	while(count < 12000 * setting)
	{
		SWFlag = 0;
		P1OUT = pos;
		while(SWFlag);
		TACTL = TASSEL_2 + (ID_1 * divider) + MC_1 + TACLR + TAIE;
		SWFlag = 0;
		P1OUT = neg;
		while(SWFlag);
		TACTL = TASSEL_2 + (ID_1 * divider) + MC_1 + TACLR + TAIE;
		count++;
	}

	__disable_interrupt();
	P1OUT = 0;
}


#pragma vector = TIMER0_A0_VECTOR
__interrupt void TA_FFF2_ISR(void) {
	SWFlag = 1;
	TACTL &= ~TAIFG;
	return;
}

#pragma vector = TIMER0_A1_VECTOR
__interrupt void TA_FFF0_ISR(void) {
	SWFlag = 1;
	TACTL &= ~TAIFG;
	return;
}

#pragma vector=ADC10_VECTOR
__interrupt void ADC10_ISR(void) {
	SWFlag = 0;
	return;
}
