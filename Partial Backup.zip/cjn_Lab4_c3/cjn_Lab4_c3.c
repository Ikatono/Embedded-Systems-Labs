#include <msp430.h> 

/*
 * main.c
 */
int main(void) {
    WDTCTL = WDTPW | WDTHOLD;	// Stop watchdog timer

    volatile char A = 0xa2;
    volatile char B = 0xef;
    volatile unsigned int runningSum = 0x0000;
    volatile char LSB;

    volatile char count = 8;

    while (count > 0)
    {
    	LSB = B & 1;

    	if (LSB == 1)
    		runningSum = runningSum + A;

    	A << 1;
    	B >> 1;
    	count = count - 1;
    }
	
	return 0;
}
