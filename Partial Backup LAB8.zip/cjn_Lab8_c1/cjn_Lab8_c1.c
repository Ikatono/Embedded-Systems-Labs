#include <msp430g2553.h>

/*
 * main.c
 */

#define LEFT 16
#define DOWN 32
#define RIGHT 64
#define UP 128
#define CENTER 1
#define SWDELAY 3

void SWtimer (int);

int main(void)
{
    WDTCTL = WDTPW | WDTHOLD;	// Stop watchdog timer
	
	volatile unsigned char meas_base[5];
	volatile unsigned char meas_crt[5];
	volatile unsigned int i;

	P1DIR |= 0xff;			//set PIN6 to out
    P1OUT &= 0x00;			//P1 outputs 0

    P2DIR &= ~BIT5;			//P2.5 input
	P2SEL &= ~BIT5;
	P2SEL2 |= BIT5;

	for (i = 0; i <= 4; i++)
	{
		TA0CTL = TASSEL_3;
		TA0CCTL1 = CM_3 + CCIS_2 + CAP;
		TA0CTL |= MC_2 + TACLR;
		SWtimer(SWDELAY);
		TA0CCTL1 ^= CCIS0;

		meas_base[i] = TA0CCR1 - 4;

		TA0CTL &= ~(MC1 + MC0);
	}

	while (1)
	{
		meas_crt[0] = 0;
		meas_crt[1] = 0;
		meas_crt[2] = 0;
		meas_crt[3] = 0;
		meas_crt[4] = 0;

		for (i = 0; i <= 4; i++)
		{
			TA0CTL = TASSEL_3;
			TA0CCTL1 = CM_3 + CCIS_2 + CAP;
			TA0CTL |= MC_2 + TACLR;
			SWtimer(SWDELAY);
			TA0CCTL1 ^= CCIS0;

			meas_crt[i] = TA0CCR1 <= meas_base[i];

			TA0CTL &= ~(MC1 + MC0);
		}

		/* causes error if and meas_cry is greater than 1
		for (i = 0; i <= 4; i++)
		{
			if (meas_crt[i] > 1)
			{
				while(1)
				{
					P1OUT = 1;
					SWtimer(SWDELAY*3);
					P1OUT = 0;
					SWtimer(SWDELAY*3);
				}
			}
		}
		*/

		P1OUT = (LEFT * meas_crt[0]) + (DOWN * meas_crt[1]) + (RIGHT * meas_crt[2]) + (UP * meas_crt[3]) + (CENTER * meas_crt[4]);
	}

	return 0;
}

void SWtimer(int delay)				//waits for delay*delay decrements
{
	volatile unsigned int wait = delay;
	volatile unsigned int count1 = wait;
	volatile unsigned int count2 = wait;

	while(count1 > 0)
	{
		while(count2 > 0)
		{
			count2--;
		}
		count1--;
		count2 = wait;
	}
	return;
}

